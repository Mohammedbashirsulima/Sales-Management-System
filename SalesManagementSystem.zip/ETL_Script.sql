
-- إنشاء جدول مؤقت للمنتجات الجديدة
CREATE TABLE TempProducts (
    ProductName NVARCHAR(100),
    Price DECIMAL(10,2),
    Stock INT
);

-- تحميل البيانات من الجدول المؤقت إلى Products
INSERT INTO Products (ProductName, Price, Stock)
SELECT ProductName, Price, Stock
FROM TempProducts;
